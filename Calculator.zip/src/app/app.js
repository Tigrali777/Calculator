import './app.scss'

const App = () => {
    const appWrapper = document.createElement('div')
    appWrapper.className = "app"

    const sectionScreen = document.createElement('section')
    sectionScreen.className = "app__screen"
    sectionScreen.innerText = "0"
    
    const sectionCalcButtons = document.createElement('section')
    sectionCalcButtons.className = "app__calc-buttons"

    const calcButtonRow1 = document.createElement('div')
    calcButtonRow1.className = "app__calc-button-row"

    const double = document.createElement('button')
    double.className = "app__calc-button double"
    double.innerText = "C"

    const larr = document.createElement('button')
    larr.className = "app__calc-button "
    larr.innerText = "←"

    const divide = document.createElement('button')
    divide.className = "app__calc-button"
    divide.innerText = "÷"

    const calcButtonRow2 = document.createElement('div')
    calcButtonRow2.className = "app__calc-button-row"

    const button7 = document.createElement('button')
    button7.className = "app__calc-button"
    button7.innerText = "7"
    const button8 = document.createElement('button')
    button8.className = "app__calc-button"
    button8.innerText = "8"
    const button9 = document.createElement('button')
    button9.className = "app__calc-button"
    button9.innerText = "9"
    
    const buttonTimes = document.createElement('button')
    buttonTimes.className = "app__calc-button"
    buttonTimes.innerText = "x"
    
    const calcButtonRow3 = document.createElement('div')
    calcButtonRow3.className = "app__calc-button-row"

    const button4 = document.createElement('button')
    button4.className = "app__calc-button"
    button4.innerText = "4"
    const button5 = document.createElement('button')
    button5.className = "app__calc-button"
    button5.innerText = "5"
    const button6 = document.createElement('button')
    button6.className = "app__calc-button"
    button6.innerText = "6"
    
    const buttonMinus = document.createElement('button')
    buttonMinus.className = "app__calc-button"
    buttonMinus.innerText = "−"
    
    const calcButtonRow4 = document.createElement('div')
    calcButtonRow4.className = "app__calc-button-row"

    const button1 = document.createElement('button')
    button1.className = "app__calc-button"
    button1.innerText = "1"
    const button2 = document.createElement('button')
    button2.className = "app__calc-button"
    button2.innerText = "2"
    const button3 = document.createElement('button')
    button3.className = "app__calc-button"
    button3.innerText = "3"
    
    const buttonPlus = document.createElement('button')
    buttonPlus.className = "app__calc-button"
    buttonPlus.innerText = "+"

    const calcButtonRow5 = document.createElement('div')
    calcButtonRow5.className = "app__calc-button-row"

    const button0 = document.createElement('button')
    button0.className = "app__calc-button triple"
    button0.innerText = "0"
    
    const buttonEquals = document.createElement('button')
    buttonEquals.className = "app__calc-button"
    buttonEquals.innerText = "="
    
    appWrapper.appendChild(sectionScreen)
    appWrapper.appendChild(sectionCalcButtons)
    
    sectionCalcButtons.appendChild(calcButtonRow1)
    calcButtonRow1.appendChild(double)
    calcButtonRow1.appendChild(larr)
    calcButtonRow1.appendChild(divide)

    sectionCalcButtons.appendChild(calcButtonRow2)
    calcButtonRow2.appendChild(button7)
    calcButtonRow2.appendChild(button8)
    calcButtonRow2.appendChild(button9)
    calcButtonRow2.appendChild(buttonTimes)

    sectionCalcButtons.appendChild(calcButtonRow3)
    calcButtonRow3.appendChild(button4)
    calcButtonRow3.appendChild(button5)
    calcButtonRow3.appendChild(button6)
    calcButtonRow3.appendChild(buttonMinus)

    sectionCalcButtons.appendChild(calcButtonRow4)
    calcButtonRow4.appendChild(button1)
    calcButtonRow4.appendChild(button2)
    calcButtonRow4.appendChild(button3)
    calcButtonRow4.appendChild(buttonPlus)

    sectionCalcButtons.appendChild(calcButtonRow5)
    calcButtonRow5.appendChild(button0)
    calcButtonRow5.appendChild(buttonEquals)
    
    return appWrapper
}

export default App